#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "matrix.h"
#define buffer 10000

int main() {
    int q;
    scanf("%d", &q);
    while(q--){
        char string[20];
        int m;
        scanf("%s", string);
        scanf("%d", &m);
        // add_matrix 0
        if(strcmp(string, "add_matrix")==0 && m==0){ 
            operation("add_matrix 0");
            int r1, c1, r2, c2;
            scanf("%d %d", &r1, &c1);
            Matrix* matrix1 = create_matrix(r1, c1);
            for (int i = 0; i < matrix1->num_rows; i++) {
                for (int j = 0; j < matrix1->num_cols; j++) {
                    scanf("%lld", &matrix1->data[i][j]);
                }
            }
            scanf("%d %d", &r2, &c2);
            Matrix* matrix2 = create_matrix(r2, c2);
            for (int i = 0; i < matrix2->num_rows; i++) {
                for (int j = 0; j < matrix2->num_cols; j++) {
                    scanf("%lld", &matrix2->data[i][j]);
                }
            }
            Matrix* ans = add_matrix(matrix1, matrix2);
            if(ans!=NULL){
                print_matrix(ans);
            }
            else{
                printf("ERROR: INVALID ARGUMENT\n");
            }
        }
        //add_matrix 1
        if(strcmp(string, "add_matrix")==0 && m==1){
            operation("add_matrix 1");
            char file_name_1[buffer];
            char file_name_2[buffer];
            char file_output[buffer];
            scanf("%s", file_name_1);
            scanf("%s", file_name_2);
            scanf("%s", file_output);
            Matrix* matrix1 = read_matrix_from_file(file_name_1);
            Matrix* matrix2 = read_matrix_from_file(file_name_2);
            Matrix* ans;
            if(matrix1!=NULL && matrix2!=NULL){
                ans = add_matrix(matrix1, matrix2);
                if(ans!=NULL){
                    write_matrix_to_file(file_output, ans);
                }
                else{
                    printf("ERROR: INVALID ARGUMENT\n");
                }
            }
            else{
                printf("ERROR: INVALID ARGUMENT\n");
            }
        }
        //mult_matrix 0
        if(strcmp(string, "mult_matrix")==0 && m==0){ 
            operation("mult_matrix 0");
            int r1, c1, r2, c2;
            scanf("%d %d", &r1, &c1);
            Matrix* matrix1 = create_matrix(r1, c1);
            for (int i = 0; i < matrix1->num_rows; i++) {
                for (int j = 0; j < matrix1->num_cols; j++) {
                    scanf("%lld", &matrix1->data[i][j]);
                }
            }
            scanf("%d %d", &r2, &c2);
            Matrix* matrix2 = create_matrix(r2, c2);
            for (int i = 0; i < matrix2->num_rows; i++) {
                for (int j = 0; j < matrix2->num_cols; j++) {
                    scanf("%lld", &matrix2->data[i][j]);
                }
            }
            Matrix* ans = mult_matrix(matrix1, matrix2);
            if(ans!=NULL){
                print_matrix(ans);
            }
            else{
                printf("ERROR: INVALID ARGUMENT\n");
            }
        }
        //mult_matrix 1
        if(strcmp(string, "mult_matrix")==0 && m==1){ 
            operation("mult_matrix 1");
            char file_name_1[buffer];
            char file_name_2[buffer];
            char file_output[buffer];
            scanf("%s", file_name_1);
            scanf("%s", file_name_2);
            scanf("%s", file_output);
            Matrix* matrix1 = read_matrix_from_file(file_name_1);
            Matrix* matrix2 = read_matrix_from_file(file_name_2);
            Matrix* ans;
            if(matrix1!=NULL && matrix2!=NULL){
                ans = mult_matrix(matrix1, matrix2);
                if(ans!=NULL){
                    write_matrix_to_file(file_output, ans);
                }
                else{
                    printf("ERROR: INVALID ARGUMENT\n");
                }
            }
            else{
                printf("ERROR: INVALID ARGUMENT\n");
            }
        }
        // scalar_mult_matrix 0
        if(strcmp(string, "scalar_mult_matrix")==0 && m==0){ 
            operation("scalar_mult_matrix 0");
            long long s;
            scanf("%lld", &s);
            int r, c;
            scanf("%d %d", &r, &c);
            Matrix* matrix = create_matrix(r, c);
            for (int i = 0; i < matrix->num_rows; i++) {
                for (int j = 0; j < matrix->num_cols; j++) {
                    scanf("%lld", &matrix->data[i][j]);
                }
            }
            Matrix* ans = scalar_mult_matrix(s, matrix);
            print_matrix(ans);
        }
        // scalar_mult_matrix 1
        if(strcmp(string, "scalar_mult_matrix")==0 && m==1){
            operation("scalar_mult_matrix 1");
            long long s;
            scanf("%lld", &s); 
            char file_input[buffer];
            char file_output[buffer];
            scanf("%s", file_input);
            scanf("%s", file_output);
            Matrix* matrix = read_matrix_from_file(file_input);
            Matrix* ans;
            if(matrix!=NULL){
                ans = scalar_mult_matrix(s, matrix);
                if(ans!=NULL){
                    write_matrix_to_file(file_output, ans);
                }
                else{
                    printf("ERROR: INVALID ARGUMENT\n");
                }
            }
            else{
                printf("ERROR: INVALID ARGUMENT\n");
            }
        }
        //transpose matrix 0
        if(strcmp(string, "transpose_matrix")==0 && m==0){
            operation("transpose_matrix 0");
            int r, c;
            scanf("%d %d", &r, &c);
            Matrix* matrix = create_matrix(r, c);
            for (int i = 0; i < matrix->num_rows; i++) {
                for (int j = 0; j < matrix->num_cols; j++) {
                    scanf("%lld", &matrix->data[i][j]);
                }
            }
            Matrix* ans = transpose_matrix(matrix);
            print_matrix(ans);
        }
        //transpose matrix 1
        if(strcmp(string, "transpose_matrix")==0 && m==1){
            operation("transpose_matrix 1");
            char file_input[buffer];
            char file_output[buffer];
            scanf("%s", file_input);
            scanf("%s", file_output);
            Matrix* matrix = read_matrix_from_file(file_input);
            Matrix* ans;
            if(matrix!=NULL){
                ans = transpose_matrix(matrix);
                if(ans!=NULL){
                    write_matrix_to_file(file_output, ans);
                }
                else{
                    printf("ERROR: INVALID ARGUMENT\n");
                }
            }
            else{
                printf("ERROR: INVALID ARGUMENT\n");
            }
        }
        //determinant 0
        if(strcmp(string, "determinant")==0 && m==0){
            operation("determinant 0");
            int r, c;
            scanf("%d %d", &r, &c);
            Matrix* matrix = create_matrix(r, c);
            for (int i = 0; i < matrix->num_rows; i++) {
                for (int j = 0; j < matrix->num_cols; j++) {
                    scanf("%lld", &matrix->data[i][j]);
                }
            }
            if(matrix->num_cols!=matrix->num_rows){
                printf("ERROR: INVALID ARGUMENT\n");
            }
            else{
                printf("%lld\n", determinant(matrix));
            }
        }
        //determinant 1
        if(strcmp(string, "determinant")==0 && m==1){
            operation("determinant 1");
            char file_input[buffer];
            scanf("%s", file_input);
            Matrix* matrix = read_matrix_from_file(file_input);
            if(matrix!=NULL){
                if(matrix->num_cols!=matrix->num_rows){
                    printf("ERROR: INVALID ARGUMENT\n");
                }
                else{
                    printf("%lld\n", determinant(matrix));
                }
            }
            else{
                printf("ERROR: INVALID ARGUMENT\n");
            }
        }
        //history
        if(strcmp(string, "history")==0){
            operation("history");
            history();
        }
    }
    return 0; 
}
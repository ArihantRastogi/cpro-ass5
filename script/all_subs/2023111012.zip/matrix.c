#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define buffer 10000

typedef struct Matrix {
    int        num_rows;
    int        num_cols;
    long long int**     data;
} Matrix;

Matrix* create_matrix(int r, int c) {
    Matrix* m = (Matrix*) malloc(sizeof(Matrix));
    m->num_rows = r;
    m->num_cols = c;
    m->data = (long long int**) calloc(r, sizeof(long long int*));
    for (int i =0; i < r; i++) {
        m->data[i] = (long long int*) calloc(c, sizeof(long long int));
    }
return m; }

void destroy_matrix(Matrix* m) {
    // 1: Write code here to free all memory used by the matrix stored in m
    for (int i =0; i < m->num_rows; i++) {
        if(m->data[i]!=NULL){
            free(m->data[i]);
        }
    }
    if(m->data!=NULL){
        free(m->data);
    }
    if(m!=NULL){
        free(m);
    }
}

Matrix* add_matrix(Matrix* A, Matrix* B) {
   // 2: write code here to add the matrices A and B and return a new matrix with the results.
   // A, B should remain unmodified. If dimensions don't match, it should return NULL.
    if(A->num_rows==B->num_rows && A->num_cols==B->num_cols){
        Matrix* m = create_matrix(A->num_rows, A->num_cols);
        for(int i=0; i<A->num_rows; i++){
            for(int j=0; j<A->num_cols; j++){
                m->data[i][j]=A->data[i][j]+B->data[i][j];
            }
        }
        return m;
    }
    else{
        return NULL;
    }
}

Matrix* mult_matrix(Matrix* A, Matrix* B) {
    // 3: write code here to multiply the matrices A and B and return a new matrix with the results.
    // A, B should remain unmodified. If the dimensions don't match, it should return NULL.
    if(A->num_cols==B->num_rows){
        Matrix* m = create_matrix(A->num_rows, B->num_cols);
        int ans=0;
        for(int k=0; k<B->num_cols; k++){
            for(int i=0; i<A->num_rows; i++){
                for(int j=0; j<A->num_cols; j++){
                    m->data[i][k]+=A->data[i][j]*B->data[j][k];
                }
            }
        }
        return m;
    }
    else{
        return NULL;
    }
}

Matrix* scalar_mult_matrix(long long int s, Matrix* M) {
    // 4: write code here to multiply the matrix A with a scalar s and return a new matrix with the results.
    // M should remain unmodified.
    Matrix* m = create_matrix(M->num_rows, M->num_cols);
    for(int i=0; i<M->num_rows; i++){
        for(int j=0; j<M->num_cols; j++){
            m->data[i][j]=M->data[i][j]*s;
        }
    }
    return m;
}

Matrix* transpose_matrix(Matrix* A) {
   // 5: write code here to find the transpose of given matrix A and return a new matrix with the results.
   // A should remain unmodified.
    Matrix* m = create_matrix(A->num_cols, A->num_rows);
    for(int i=0; i<A->num_rows; i++){
        for(int j=0; j<A->num_cols; j++){
            m->data[j][i]=A->data[i][j];
        }
    }
    return m;
}

long long int determinant(Matrix* M) {
    // 6: Write code here to calculate the determinant of the given matrix M (if not a square matrix, return -1).
    // Return the determinant value.
    if(M->num_cols!=M->num_rows){
        return -1;
    }
    if(M->num_cols==1){
        return M->data[0][0];
    }
    else{
        long long int ans=0;
        int n = M->num_cols;
        Matrix* submatrix = create_matrix(n-1, n-1);
        for(int i=0; i<n; i++){
            for(int j=0; j<n-1; j++){
                int column=0;
                for(int k=0; k<n-1; k++){
                    if(i==column){
                        column++;
                    }
                    submatrix->data[j][k]=M->data[j+1][column];
                    column++;
                }
            }
            if(i%2==0){
                ans+=M->data[0][i]*determinant(submatrix);
            }
            else{
                ans-=M->data[0][i]*determinant(submatrix);
            }
        }
        return ans;
    }
}

Matrix* read_matrix_from_file(char* file){
    FILE *fptr;
    fptr = fopen(file, "r");
    if(fptr==NULL){
        return NULL;
    }
    int r, c;
    fscanf(fptr, "%d", &r);
    fscanf(fptr, "%d", &c);
    Matrix* matrix = create_matrix(r, c);
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            fscanf(fptr, "%lld", &matrix->data[i][j]);
        }
    }
    fclose(fptr);
    return matrix;
}

Matrix* write_matrix_to_file(char* file, Matrix* matrix){
    FILE *fptr;
    fptr = fopen(file, "w");
    if(fptr==NULL){
        printf("ERROR: INVALID ARGUMENT\n");
        return NULL;
    }
    fprintf(fptr, "%d %d\n", matrix->num_rows, matrix->num_cols);
    for (int i = 0; i < matrix->num_rows; i++) {
        for (int j = 0; j < matrix->num_cols; j++) {
            fprintf(fptr, "%lld ", matrix->data[i][j]);
        }
        fprintf(fptr, "\n");
    }
    fclose(fptr);
    return matrix;
}

void operation(char* operation) {
    FILE* fptr;
    fptr = fopen("mx_history", "a");
    if(fptr==NULL){
        printf("ERROR: INVALID ARGUMENT\n");
    } 
    else {
        fprintf(fptr, "LOG::%s\n", operation);
    }    
    fclose(fptr);
}

void history() {
    FILE* fptr;
    fptr = fopen("mx_history", "r");
    if (fptr == NULL) {
        printf("ERROR: INVALID ARGUMENT\n");
    } 
    else {
        char line[buffer];
        while (fgets(line, sizeof(line), fptr)!=NULL) {
            printf("%s", line);
        }
    }
    fclose(fptr);
}

// DO NOT MODIFY THE OUTPUT FORMAT of this function. Will be used for grading
void print_matrix(Matrix* m) {
    printf("%d %d\n", m->num_rows, m->num_cols);
    for (int i = 0; i < m->num_rows; i++) {
        for (int j = 0; j < m->num_cols; j++) {
            printf("%lld ", m->data[i][j]);
        }
        printf("\n");
    }
}